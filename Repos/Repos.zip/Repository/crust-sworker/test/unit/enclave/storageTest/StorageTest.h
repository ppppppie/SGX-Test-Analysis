#ifndef _CRUST_STORAGE_TEST_H_
#define _CRUST_STORAGE_TEST_H_

#include "Storage.h"
#include "stdbool.h"


#if defined(__cplusplus)
extern "C"
{
#endif

bool test_get_hashs_from_block();

#if defined(__cplusplus)
}
#endif


#endif /* !_CRUST_STORAGE_TEST_H_ */