#ifndef _CRUST_ENLCAVE_TEST_ENTRANCE_H_
#define _CRUST_ENLCAVE_TEST_ENTRANCE_H_

#include "UtilsTest.h"
#include "StorageTest.h"


#if defined(__cplusplus)
extern "C"
{
#endif

bool test_enclave_unit();

#if defined(__cplusplus)
}
#endif

#endif /* !_CRUST_ENLCAVE_TEST_ENTRANCE_H_ */