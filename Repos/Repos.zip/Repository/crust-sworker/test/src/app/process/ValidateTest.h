#ifndef _APP_VALIDATE_TEST_H_
#define _APP_VALIDATE_TEST_H_

#include <vector>

#include "Config.h"
#include "Ctpl.h"

#if defined(__cplusplus)
extern "C"
{
#endif

void validate_file_test();
void validate_srd_test();

#if defined(__cplusplus)
}
#endif

#endif /* ! _APP_VALIDATE_TEST_H_ */
