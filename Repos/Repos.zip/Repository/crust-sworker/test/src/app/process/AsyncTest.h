#ifndef _APP_ASYNC_TEST_H_
#define _APP_ASYNC_TEST_H_

#include <string>
#include <future>
#include "Log.h"
#include "Chain.h"


#if defined(__cplusplus)
extern "C"
{
#endif

void report_add_callback();

#if defined(__cplusplus)
}
#endif

#endif /* !_APP_ASYNC_TEST_H_ */
