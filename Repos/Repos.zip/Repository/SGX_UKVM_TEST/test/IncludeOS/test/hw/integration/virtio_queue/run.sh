#! /bin/bash
source ${INCLUDEOS_HOME-$HOME/IncludeOS_install}/etc/run.sh test_virtio_queue.img
