#! /bin/bash
export DEV_GRAPHICS="-vga std"
source ${INCLUDEOS_HOME-$HOME/IncludeOS_install}/etc/run.sh test_vga.img
