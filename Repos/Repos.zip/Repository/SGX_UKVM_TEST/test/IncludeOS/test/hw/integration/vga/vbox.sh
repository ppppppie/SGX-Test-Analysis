#!/bin/bash
../../etc/vboxrun.sh Test.img
