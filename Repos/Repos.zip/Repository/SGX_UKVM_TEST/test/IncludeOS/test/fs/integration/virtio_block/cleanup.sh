#!/bin/bash
echo "Cleaning up after test..."
rm image.img
echo "Done"
