#include <common.cxx>
#include <mock_fs.hpp>

using namespace fs;

CASE("Initialize mock FS")
{
  MockFS fs;
  
}
